
  # 혈당 관리 시나리오 구축

  This is a code bundle for 혈당 관리 시나리오 구축. The original project is available at https://www.figma.com/design/9xrKugNOIni7d42uUdjeou/%ED%98%88%EB%8B%B9-%EA%B4%80%EB%A6%AC-%EC%8B%9C%EB%82%98%EB%A6%AC%EC%98%A4-%EA%B5%AC%EC%B6%95.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, TrendingUp, Activity, Droplet, Utensils, CheckCircle2, RotateCcw } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { Button } from '@/app/components/ui/button';
import { Card } from '@/app/components/ui/card';
import { Progress } from '@/app/components/ui/progress';

type Step = 'detection' | 'visualization' | 'action' | 'feedback';

const bloodSugarData = [
  { time: '8:00', value: 95, label: '아침' },
  { time: '8:30', value: 98, label: '식사' },
  { time: '9:00', value: 135, label: '식후 30분' },
  { time: '9:30', value: 180, label: '현재' },
];

const bloodSugarDataAfter = [
  { time: '8:00', value: 95, label: '아침' },
  { time: '8:30', value: 98, label: '식사' },
  { time: '9:00', value: 135, label: '식후 30분' },
  { time: '9:30', value: 180, label: '스파이크' },
  { time: '10:00', value: 155, label: '산책 중' },
  { time: '10:15', value: 125, label: '안정화' },
];

const actionCards = [
  {
    id: 'exercise',
    icon: Activity,
    emoji: '🚶‍♂️',
    title: '운동',
    subtitle: '가벼운 산책 15분',
    description: '혈당을 가장 빠르게 낮추는 방법입니다.',
    color: 'from-blue-500/10 to-blue-600/10 border-blue-500/20',
    iconColor: 'text-blue-600',
  },
  {
    id: 'water',
    icon: Droplet,
    emoji: '💧',
    title: '수분',
    subtitle: '미지근한 물 2컵',
    description: '혈당 농도 조절에 도움을 줍니다.',
    color: 'from-cyan-500/10 to-cyan-600/10 border-cyan-500/20',
    iconColor: 'text-cyan-600',
  },
  {
    id: 'food',
    icon: Utensils,
    emoji: '🥗',
    title: '기록',
    subtitle: '식단 체크',
    description: '방금 드신 음식에 당분이 많았나요? 기록해 두면 다음엔 예방할 수 있어요.',
    color: 'from-green-500/10 to-green-600/10 border-green-500/20',
    iconColor: 'text-green-600',
  },
];

export default function App() {
  const [step, setStep] = useState<Step>('detection');
  const [selectedAction, setSelectedAction] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // Calculate progress based on step
    const progressMap = {
      detection: 25,
      visualization: 50,
      action: 75,
      feedback: 100,
    };
    setProgress(progressMap[step]);
  }, [step]);

  const handleActionSelect = (actionId: string) => {
    setSelectedAction(actionId);
    setTimeout(() => {
      setStep('feedback');
    }, 300);
  };

  const handleReset = () => {
    setStep('detection');
    setSelectedAction(null);
  };

  const handleNext = () => {
    if (step === 'detection') setStep('visualization');
    else if (step === 'visualization') setStep('action');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-orange-50 to-amber-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Progress Bar */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-sm font-medium text-gray-600">혈당 관리 루프</h2>
            <span className="text-sm text-gray-500">
              {step === 'detection' && 'Step 1/4'}
              {step === 'visualization' && 'Step 2/4'}
              {step === 'action' && 'Step 3/4'}
              {step === 'feedback' && 'Step 4/4'}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Main Content */}
        <AnimatePresence mode="wait">
          {/* Step 1: Detection */}
          {step === 'detection' && (
            <motion.div
              key="detection"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
            >
              <Card className="p-8 md:p-12 bg-white/80 backdrop-blur-sm border-2 border-orange-200 shadow-xl">
                <div className="flex items-start gap-4 mb-6">
                  <div className="p-3 bg-orange-100 rounded-full">
                    <AlertTriangle className="w-8 h-8 text-orange-600 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Step 1. 위험 감지 및 알림 (Detection)
                    </h3>
                    <p className="text-sm text-gray-600">
                      식후 30분, 혈당 급상승(스파이크) 감지
                    </p>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-orange-50 to-rose-50 border-l-4 border-orange-500 p-6 rounded-lg mb-8">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-2xl">⚠️</span>
                    <h4 className="text-xl font-bold text-gray-900">혈당 스파이크 주의!</h4>
                  </div>
                  <p className="text-gray-700">
                    식후 혈당이 가파르게 오르고 있어요. 지금 바로 조치가 필요합니다.
                  </p>
                </div>

                <Button
                  onClick={handleNext}
                  className="w-full bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-600 hover:to-rose-600 text-white py-6 text-lg"
                >
                  자세히 보기
                </Button>
              </Card>
            </motion.div>
          )}

          {/* Step 2: Visualization */}
          {step === 'visualization' && (
            <motion.div
              key="visualization"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
            >
              <Card className="p-8 md:p-12 bg-white/80 backdrop-blur-sm border-2 border-purple-200 shadow-xl">
                <div className="flex items-start gap-4 mb-6">
                  <div className="p-3 bg-purple-100 rounded-full">
                    <TrendingUp className="w-8 h-8 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Step 2. 직관적 시각화 (Visualization)
                    </h3>
                    <p className="text-sm text-gray-600">
                      현재 수치와 위험성 설명
                    </p>
                  </div>
                </div>

                {/* Blood Sugar Chart */}
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-lg mb-6">
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={bloodSugarData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                      <XAxis dataKey="time" stroke="#6b7280" />
                      <YAxis stroke="#6b7280" domain={[80, 200]} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'white',
                          border: '1px solid #e5e7eb',
                          borderRadius: '8px',
                        }}
                      />
                      <ReferenceLine
                        y={140}
                        stroke="#ef4444"
                        strokeDasharray="3 3"
                        label={{ value: '위험', position: 'right', fill: '#ef4444' }}
                      />
                      <ReferenceLine
                        y={100}
                        stroke="#10b981"
                        strokeDasharray="3 3"
                        label={{ value: '정상', position: 'right', fill: '#10b981' }}
                      />
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke="#8b5cf6"
                        strokeWidth={3}
                        dot={{ fill: '#8b5cf6', r: 5 }}
                        activeDot={{ r: 7 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                {/* Current Stats */}
                <div className="bg-gradient-to-r from-red-50 to-orange-50 border-l-4 border-red-500 p-6 rounded-lg mb-8">
                  <div className="flex items-baseline gap-3 mb-3">
                    <span className="text-4xl font-bold text-red-600">180</span>
                    <span className="text-lg text-gray-600">mg/dL</span>
                  </div>
                  <p className="text-gray-700 leading-relaxed">
                    현재 수치 <strong>180mg/dL</strong>. 평소보다 상승 속도가 <strong>1.5배</strong> 빠릅니다.
                    이 상태가 유지되면 인슐린 저항성에 영향을 줄 수 있어요.
                  </p>
                </div>

                <Button
                  onClick={handleNext}
                  className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white py-6 text-lg"
                >
                  해결 방법 보기
                </Button>
              </Card>
            </motion.div>
          )}

          {/* Step 3: Action */}
          {step === 'action' && (
            <motion.div
              key="action"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
            >
              <Card className="p-8 md:p-12 bg-white/80 backdrop-blur-sm border-2 border-blue-200 shadow-xl">
                <div className="flex items-start gap-4 mb-6">
                  <div className="p-3 bg-blue-100 rounded-full">
                    <Activity className="w-8 h-8 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Step 3. 맞춤형 행동 가이드 (Actionable Insight)
                    </h3>
                    <p className="text-sm text-gray-600">
                      즉시 실천 가능한 3가지 옵션 제공
                    </p>
                  </div>
                </div>

                <div className="mb-6">
                  <p className="text-gray-700 mb-6">
                    지금 바로 실천할 수 있는 방법을 선택해주세요:
                  </p>

                  <div className="grid gap-4">
                    {actionCards.map((card, index) => (
                      <motion.div
                        key={card.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                      >
                        <Card
                          className={`p-6 bg-gradient-to-r ${card.color} border-2 cursor-pointer hover:scale-[1.02] transition-all duration-200 hover:shadow-lg`}
                          onClick={() => handleActionSelect(card.id)}
                        >
                          <div className="flex items-start gap-4">
                            <div className="text-4xl">{card.emoji}</div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <span className="font-bold text-gray-900">[{card.title}]</span>
                                <span className="text-gray-700">{card.subtitle}</span>
                              </div>
                              <p className="text-sm text-gray-600 leading-relaxed">
                                {card.description}
                              </p>
                            </div>
                            <card.icon className={`w-6 h-6 ${card.iconColor}`} />
                          </div>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </Card>
            </motion.div>
          )}

          {/* Step 4: Feedback */}
          {step === 'feedback' && (
            <motion.div
              key="feedback"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
            >
              <Card className="p-8 md:p-12 bg-white/80 backdrop-blur-sm border-2 border-green-200 shadow-xl">
                <div className="flex items-start gap-4 mb-6">
                  <div className="p-3 bg-green-100 rounded-full">
                    <CheckCircle2 className="w-8 h-8 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Step 4. 행동 결과 및 동기 부여 (Feedback)
                    </h3>
                    <p className="text-sm text-gray-600">
                      산책 후 혈당 안정화 확인
                    </p>
                  </div>
                </div>

                {/* After Action Chart */}
                <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-6 rounded-lg mb-6">
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={bloodSugarDataAfter}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                      <XAxis dataKey="time" stroke="#6b7280" />
                      <YAxis stroke="#6b7280" domain={[80, 200]} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'white',
                          border: '1px solid #e5e7eb',
                          borderRadius: '8px',
                        }}
                      />
                      <ReferenceLine
                        y={140}
                        stroke="#ef4444"
                        strokeDasharray="3 3"
                        label={{ value: '위험', position: 'right', fill: '#ef4444' }}
                      />
                      <ReferenceLine
                        y={100}
                        stroke="#10b981"
                        strokeDasharray="3 3"
                        label={{ value: '정상', position: 'right', fill: '#10b981' }}
                      />
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke="#10b981"
                        strokeWidth={3}
                        dot={{ fill: '#10b981', r: 5 }}
                        activeDot={{ r: 7 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                {/* Success Message */}
                <div className="bg-gradient-to-r from-green-50 to-emerald-50 border-l-4 border-green-500 p-6 rounded-lg mb-6">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-3xl">👍</span>
                    <h4 className="text-xl font-bold text-gray-900">참 잘하셨어요!</h4>
                  </div>
                  <p className="text-gray-700 leading-relaxed">
                    15분 산책 덕분에 혈당이 다시 안정권으로 진입했습니다.
                    <br />
                    이런 작은 습관이 당신의 췌장을 지킵니다.
                  </p>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-2 gap-4 mb-8">
                  <div className="bg-white/60 p-4 rounded-lg text-center">
                    <div className="text-3xl font-bold text-green-600 mb-1">-55</div>
                    <div className="text-sm text-gray-600">mg/dL 감소</div>
                  </div>
                  <div className="bg-white/60 p-4 rounded-lg text-center">
                    <div className="text-3xl font-bold text-green-600 mb-1">15분</div>
                    <div className="text-sm text-gray-600">실천 시간</div>
                  </div>
                </div>

                <Button
                  onClick={handleReset}
                  className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white py-6 text-lg"
                >
                  <RotateCcw className="w-5 h-5 mr-2" />
                  처음부터 다시 보기
                </Button>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500">
            UX 시나리오: 혈당 관리 루프 데모
          </p>
        </div>
      </div>
    </div>
  );
}
